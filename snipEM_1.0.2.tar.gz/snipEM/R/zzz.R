.onLoad <- function(lib,pkg){
  library.dynam("snipEM",pkg,lib)
}
