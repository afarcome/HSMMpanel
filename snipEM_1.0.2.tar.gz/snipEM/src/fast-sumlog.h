#ifndef _fsumlog_H
#define _fsumlog_H
#include <RcppArmadillo.h>
RcppExport SEXP fast_sumlog(SEXP X, SEXP Lower, SEXP Upper, SEXP N);
#endif
