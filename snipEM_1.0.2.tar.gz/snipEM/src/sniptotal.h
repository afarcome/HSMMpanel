/* External and interal  API  of  C routines in sniptotal */

/* C code which includes this, typically includes <R.h> */

/* --------- ./sniptotal.c : -------- */
/* call via .C() from R : */
void sniptotal(double *xin, int *kin, int *itermaxin, int *Vin, int *s, int *clust, double *Din, int *nin, int *din, double *muin);
